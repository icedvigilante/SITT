﻿# finds the user profile and silently removes the offending files
Remove-Item "$env:USERPROFILE\AppData\Local\Electronic Arts\EA Services\License\*.*" -Recurse -Force -Confirm:$false

# goes into the program data directory and removes the files that are causing issue
Remove-Item "$env:PROGRAMDATA\Electronic Arts\EA Services\License\*.*" -Recurse -Force -Confirm:$false

#Launch origin
Write-Host 'You will need to set the path to your origin.exe file. Replace "origin" with the path such as "C:\Program Files (x86)\Origin\origin.exe", include the quotes'
Start-Process origin